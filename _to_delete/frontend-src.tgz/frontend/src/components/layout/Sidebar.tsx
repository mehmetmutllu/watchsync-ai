"use client";

import { useState } from "react";
import { Link, usePathname } from "@/i18n/routing";
import { useTranslations } from "next-intl";
import LanguageSwitcher from "./LanguageSwitcher";
import { usePermission } from "@/hooks/usePermission";
import {
  LayoutDashboard,
  Package,
  BarChart3,
  Users,
  UsersRound,
  CreditCard,
  Scale,
  Settings,
  ChevronLeft,
  ChevronRight,
  Watch,
  FileText,
} from "lucide-react";

// navItems will be defined inside the component to use translations

interface SidebarProps {
  collapsed: boolean;
  mobileOpen: boolean;
  onToggle: () => void;
  onMobileClose: () => void;
}

export default function Sidebar({ collapsed, mobileOpen, onToggle, onMobileClose }: SidebarProps) {
  const pathname = usePathname();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const t = useTranslations("Sidebar");
  const tc = useTranslations("Common");
  const { canManageTeam } = usePermission();

  const navItems = [
    { href: "/dashboard", label: t("dashboard"), icon: LayoutDashboard },
    { href: "/dashboard/inventory", label: t("inventory"), icon: Package },
    { href: "/dashboard/market-scanner", label: t("market_scanner"), icon: BarChart3 },
    { href: "/dashboard/billing", label: t("billing"), icon: CreditCard },
    { href: "/dashboard/crm", label: t("crm"), icon: Users },
    { href: "/dashboard/invoices", label: t("invoices"), icon: FileText },
    ...(canManageTeam() ? [{ href: "/dashboard/team", label: t("team"), icon: UsersRound }] : []),
    { href: "/dashboard/settings", label: t("settings"), icon: Settings },
  ];

  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          mobileOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onMobileClose}
      />

      {/* Sidebar */}
      <aside
        data-tour="sidebar"
        role="navigation"
        aria-label={t("nav_main")}
        className={`
          fixed top-0 start-0 z-50 h-full
          glass-strong
          flex flex-col
          transition-all duration-200 ease-in-out
          w-sidebar ${collapsed ? "md:w-sidebar-collapsed" : "md:w-sidebar"}
          md:translate-x-0 ${mobileOpen ? "max-md:translate-x-0" : "max-md:-translate-x-full"}
        `}
      >
        {/* Logo Area */}
        <div className="flex items-center h-16 px-5 border-b border-border-subtle">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-accent-blue/20 flex items-center justify-center">
              <Watch className="w-5 h-5 text-accent-blue" strokeWidth={1.5} />
            </div>
            <span
              className={`
                text-lg font-bold tracking-tight text-primary-text whitespace-nowrap
                transition-all duration-200
                ${collapsed ? "opacity-0 w-0" : "opacity-100 w-auto"}
              `}
            >
              WatchSync
              <span className="text-accent-blue"> AI</span>
            </span>
          </div>
        </div>

        {/* Navigation */}
        <nav aria-label={t("nav_pages")} className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive =
              item.href === "/dashboard"
                ? pathname === "/dashboard"
                : pathname.startsWith(item.href);
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                data-tour={item.href === "/dashboard/inventory" ? "inventory" : undefined}
                aria-current={isActive ? "page" : undefined}
                onClick={onMobileClose}
                onMouseEnter={() => setHoveredItem(item.href)}
                onMouseLeave={() => setHoveredItem(null)}
                className={`
                  group relative flex items-center gap-3 px-3 py-2.5 rounded-lg
                  transition-all duration-150
                  ${
                    isActive
                      ? "bg-accent-blue/10 text-accent-blue"
                      : "text-secondary-text hover:bg-surface-elevated hover:text-primary-text"
                  }
                `}
              >
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute start-0 top-1/2 -translate-y-1/2 h-5 w-1 rounded-e-full bg-accent-blue"
                  />
                )}
                <Icon
                  className={`flex-shrink-0 w-5 h-5 transition-colors duration-150 ${
                    isActive
                      ? "text-accent-blue"
                      : "text-secondary-text group-hover:text-primary-text"
                  }`}
                  strokeWidth={1.5}
                />
                <span
                  className={`
                    text-sm font-medium whitespace-nowrap
                    transition-all duration-200
                    ${collapsed ? "opacity-0 w-0 overflow-hidden" : "opacity-100"}
                  `}
                >
                  {item.label}
                </span>

                {/* Tooltip for collapsed state */}
                {collapsed && hoveredItem === item.href && (
                  <div className="absolute start-full ms-3 px-3 py-1.5 rounded-lg bg-surface-elevated text-primary-text text-sm font-medium shadow-[var(--shadow-elevated)] whitespace-nowrap z-50 animate-fade-in">
                    {item.label}
                  </div>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Bottom Area: Legal Links, Language Switcher & Collapse Toggle */}
        <div className="flex flex-col border-t border-border-subtle">
          {!collapsed && (
            <div className="px-4 py-2 border-b border-border-subtle flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-secondary-text">
              <Link href="/agb" className="hover:underline hover:text-accent-blue">{tc("terms_link")}</Link>
              <span>•</span>
              <Link href="/impressum" className="hover:underline hover:text-accent-blue">{tc("imprint_link")}</Link>
              <span>•</span>
              <Link href="/datenschutz" className="hover:underline hover:text-accent-blue">{tc("privacy_link")}</Link>
            </div>
          )}
          <div className={`px-3 py-3 ${collapsed ? "hidden" : "block"}`}>
            <LanguageSwitcher />
          </div>
          <button
            onClick={onToggle}
            className="w-full max-md:hidden flex items-center justify-center gap-2 px-3 py-3
              text-secondary-text hover:text-primary-text hover:bg-surface-elevated
              transition-all duration-150"
            aria-label={collapsed ? t("expand") : t("collapse")}
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4" strokeWidth={1.5} />
            ) : (
              <>
                <ChevronLeft className="w-4 h-4" strokeWidth={1.5} />
              </>
            )}
          </button>
        </div>
      </aside>
    </>
  );
}
